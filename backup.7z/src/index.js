import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; 
import firebase from "firebase "
firebase.initializeApp({
  apiKey: "AIzaSyC1vAdiAYNzJicbJzoeW54TME3VTkpbumU",
  authDomain: "testfirstfirebaseproject-3e384.firebaseapp.com",
  projectId: "testfirstfirebaseproject-3e384",
  storageBucket: "testfirstfirebaseproject-3e384.appspot.com",
  messagingSenderId: "509393424231",
  appId: "1:509393424231:web:a2bee14e2597d3fbbb69c2"
});

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);


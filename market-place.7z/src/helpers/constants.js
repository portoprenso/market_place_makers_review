export const JSON_API = "http://localhost:8000/products";
export const AUTH_API = 'http://35.223.58.241:5000';